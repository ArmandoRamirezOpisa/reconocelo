angular.module('participantes_controller',[])
        .controller('participantes',function ($scope){
           $scope.mensaje ="asdad"; 
        });

