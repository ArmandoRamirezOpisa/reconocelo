angular.module('ControllerWorks',[]).controller('Reconocelo',function ($scope){
    $scope.Saldo =0;
    
       $scope.init = function () {
   //  alert($scope.Saldo);
       
    };
    
    
    $scope.compras = function(){
     // alert($scope.Saldo);    
    };
});
