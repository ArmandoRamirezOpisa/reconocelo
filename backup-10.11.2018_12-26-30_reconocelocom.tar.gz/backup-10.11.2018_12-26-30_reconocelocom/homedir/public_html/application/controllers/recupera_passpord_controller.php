<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Recupera_passpord_controller extends CI_Controller {
            
        public function RecuperarUsuario()
    	{   
            $this->load->view('recuperaPasword_view');
           
            
    	}    
    }
    
?>