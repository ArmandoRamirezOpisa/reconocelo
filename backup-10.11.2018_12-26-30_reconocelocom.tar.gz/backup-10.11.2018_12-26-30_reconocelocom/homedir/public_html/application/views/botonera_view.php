    <div id="botonera">
        <div onclick="loadSection('reglas_controller','dvSecc')" style="cursor:pointer" class="btn_m btn1">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Clipboard.png"></span>
            <h3 class="btnTit">Reglas</h3>
        </div>
        <div onclick="loadSection('cart_controller/getCategory','dvSecc')" class="btn_m btn3" style="cursor:pointer">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Gift-Box.png"></span>
            <h3 class="btnTit">Premios</h3>
        </div>
        <div onclick="loadSection('canje_controller/getCanjes','dvSecc')" class="btn_m btn4" style="cursor:pointer">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Pocket.png"></span>
            <h3 class="btnTit">Mis Canjes</h3>
        </div>
    </div>