<div class="col-md-12">
	<h2>Contenido de la orden</h2>
	<div class="table-responsive">
	  <table class="table table-bordered">
	    <thead>
	    	<tr>
	    		<th class="thHeadCart">C&oacute;digo</th>
	    		<th class="thHeadCart">Nombre</th>
	    		<th class="thHeadCart">Cantidad</th>
	    		<th class="thHeadCart">Valor Puntos</th>
                        <th class="thHeadCart"></th>
	    	</tr>	
	    </thead>
	    <tbody id = "bodyContentCart">
	    	
	    </tbody>
	  </table>
	</div>
    
    <br>

    </div><br>
    
    <!--<div style="text-align:left;float:left;"><h4>Direcci&oacute;n de env&iacute;o</h4>-->
    <?php
       /* echo $this->session->userdata('calle')."<br>";
        echo $this->session->userdata('colonia')."<br>";
        echo $this->session->userdata('cp')."<br>";
        echo $this->session->userdata('ciudad')."<br>";
        echo $this->session->userdata('estado')."<br><br>";*/
    ?>
    
    <br><br>
    <!--<a href="javascript:void(0)" onclick="loadSection('cart_controller/getCategory','dvSecc')" class="btn btn-warning" id="btnGenCanje">Continuar comprando</a>-->



    <!--ACCIONES Y FOMRULARIO DE DIRECCIONES-->
    <h3 style='text-align:left;'>Direcci&oacute;n de entrega.
    <small>Ingrese o actualice la direcci&oacute;n a la que ser&aacute;n enviados los productos.</small>
    </h3>
		<form id="frmCanjeDir">
			  <div class="form-group" id="gedo">
			    <input type="text" class="form-control" id="edo" name="edo" placeholder="Estado" required>
			  </div>
			  <div class="form-group" id="gdelmuni">
			    <input type="text" class="form-control" id="delmuni" name="delmuni" placeholder="Delegación/Municipio" required>
			  </div>
			  <div class="form-group" id="gcol">
			    <input type="text" class="form-control" id="col" name="col" placeholder="Colonia" required>
			  </div>
			  <div class="form-group" id="gnum">
			    <input type="text" class="form-control" id="num" name="num" placeholder="Calle y Número" required>
			  </div>
			  <div class="form-group" id="gcp">
			    <input type="text" class="form-control" id="cp" name="cp" placeholder="C.P." required>
			  </div>
		</form>
	    <button id="btnGenCanje" onclick="sendCanje(<?php echo $this->session->userdata('puntos'); ?>,totPuntos)" type="button" class="btn btn-default btnDef" style="margin-bottom: 50px">Finalizar compra</button>
    <!--TERMINA ACCIONES Y FORMULARIO DE DIRECCIÓN-->
<br><br>

</div>
   
<script>
	var str = "";
	var c = 0;
	var ctd;
	var totPuntos = 0;
	
	$.each(contOrder, function(k,v){
		totPuntos = totPuntos + v.puntos;
		if (c == 0)
		{
			ctd = "class = 'warning'"; 
			c = 1;
		}else{
			ctd = "";
			c = 0;
		}
		str += "<tr "+ctd+"><td>"+v.id+"</td><td>"+v.nombre+"</td><td>"+v.cantidad+"</td><td>"+formatNumber.new(v.puntos)+"</td><td><a style='cursor:pointer' onClick='deleteItem("+v.id+")'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a></td></tr>";
		$("#bodyContentCart").html(str);
	});

	str = "<tr><td colspan = 3 style ='text-align:right;'><h2>Total:</h2></td><td><h2>"+formatNumber.new(totPuntos)+"</h2></td></tr>";
	str += "<tr><td border=0><button id=\"addGenCanje\" onclick=\"loadSection('cart_controller/getCategory','dvSecc')\" type=\"button\" class=\"btn btn-default btnDef\">Continuar comprando</button></td></tr>";
	$("#bodyContentCart").append(str);
</script>