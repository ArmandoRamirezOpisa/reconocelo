<div style="text-align:center;width:100%;height:100%;">
    <img style="width:40%;height:auto;" src="http://www.puntosheinz.com.mx/assets/images/logo.png"><br>
    <center><h1>Pr&oacute;ximamente</h1></center>
</div>

