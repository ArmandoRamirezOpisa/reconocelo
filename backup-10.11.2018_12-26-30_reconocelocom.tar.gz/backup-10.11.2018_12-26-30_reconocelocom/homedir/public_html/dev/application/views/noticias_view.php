<div class="row">
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img src="assets/images/noticias/1.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 1</h3>
              <p>...</p>
              <p><a href="javascript:void(0)" onClick="loadSection('noticias_controller/getInfo','dvSecc')" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img src="assets/images/noticias/2.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 2</h3>
              <p>...</p>
              <p><a href="#" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img style='max-height:183px' src="assets/images/noticias/3.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 3</h3>
              <p>...</p>
              <p><a href="#" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
</div>
<div class = "row">
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img src="assets/images/noticias/4.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 4</h3>
              <p>...</p>
              <p><a href="#" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img src="assets/images/noticias/5.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 5</h3>
              <p>...</p>
              <p><a href="#" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
            <img src="assets/images/noticias/6.jpg" alt="...">
            <div class="caption">
              <h3>Noticia 6</h3>
              <p>...</p>
              <p><a href="#" class="btn btn-default" role="button">Ver Más</a></p>
            </div>
        </div>
    </div>
</div>
<br>
<br>