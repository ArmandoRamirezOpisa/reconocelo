
        <div id="botonera">
            <div class="btn btn1">
                <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Clipboard.png"></span>
                <h3 class="btnTit">Reglas</h3>
            </div>
            <div class="btn btn2">
                <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Compas.png"></span>
                <h3 class="btnTit">Productos</h3>
            </div>
            <div class="btn btn3">
                <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Gift-Box.png"></span>
                <h3 class="btnTit">Premios</h3>
            </div>
            <div class="btn btn4">
                <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Pocket.png"></span>
                <h3 class="btnTit">Mis Canjes</h3>
            </div>
        </div>