<div class="container">
    <div class="row">
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-Mustard_Straight.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-abal-mayonesa.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-mayonesa-room-service.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-mayoneza-heinz.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-miniature-mustard.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-mostaza-heinz.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/aderezos-yellow-mustard-9-oz.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-CreamyAlfredo-light.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-FourCheeseAlfredo.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-Mushroom&RipeOlives.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-Organic_TomHerb&Spices.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-Sundried-Tomato.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-creamy-alfredo.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/clasico-roasted-garlic-alfredo.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/otros-Hot-Dog-Relish.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/otros-Sweet-Relish.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/otros-WINE-VINEGAR.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/otros-viangre-blanco.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/picante-chamula.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/picante-jalapeno-heinz.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/picante-salsa-roja.png">
            </div>
        </div>
        <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
                <img class="dvProductsMin" src="assets/images/products/picante-salsa-tabasco.png">
            </div>
        </div>
    </div>
</div>