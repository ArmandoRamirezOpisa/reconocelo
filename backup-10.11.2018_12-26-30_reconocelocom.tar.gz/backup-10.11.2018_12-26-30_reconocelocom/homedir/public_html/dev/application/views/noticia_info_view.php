<div class="row">
    <div class="col-md-12" >
        <div class="thumbnail" style ="border:none">
            <img src="assets/images/noticias/1.jpg" alt="...">
            <div class="caption contNews" >
              <h3>Noticia 1</h3>
              <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ut vestibulum ante. Praesent nunc ante, pretium vitae blandit id, lacinia in leo. Praesent placerat erat id est faucibus, eget imperdiet sapien pharetra. Morbi auctor augue risus, ac fermentum purus cursus ac. Nunc sed velit quis sapien ornare vestibulum sed nec orci. Phasellus eros nisl, varius eget urna in, accumsan venenatis erat. Nulla eget tortor iaculis, congue mauris sed, molestie nunc. Fusce bibendum est lacus, id vulputate nisi auctor eget. Aenean turpis mauris, pellentesque vel iaculis nec, egestas sed eros. Morbi finibus dignissim massa nec efficitur. Nulla facilisi. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aenean diam enim, convallis sit amet magna ac, maximus faucibus urna. Proin vel nunc vitae est pellentesque iaculis. Proin efficitur id est sed placerat.
              </p><p>
                    Donec eget finibus diam. Phasellus a suscipit ex. In hac habitasse platea dictumst. Fusce lacinia tincidunt ipsum ut condimentum. Quisque pharetra dolor convallis risus sagittis, vitae ornare quam hendrerit. Mauris quis imperdiet mauris. In tempor laoreet ligula a malesuada. Praesent a imperdiet justo. Curabitur scelerisque vehicula rhoncus. Nullam blandit quam ac sodales placerat.
              </p><p>
                    Maecenas venenatis aliquam euismod. Aenean faucibus ante sed nisi suscipit finibus. Donec auctor pellentesque cursus. Fusce diam sapien, pharetra sit amet nisl eget, imperdiet pharetra diam. Nullam fringilla felis eu rutrum vehicula. Etiam nec viverra libero, sed pretium velit. Etiam convallis accumsan nisi sit amet rhoncus. Sed dignissim elit lorem, ac rhoncus tellus bibendum ac. Sed sollicitudin tortor arcu, in iaculis sem rutrum at. Morbi hendrerit lobortis aliquet. Nam vel ultricies sapien, ut elementum mi. Integer id bibendum arcu. Vivamus non felis eu urna tristique ultrices ut in lorem. Pellentesque nec rhoncus lectus, sed sodales libero.
              </p><p>
                    Cras vitae ligula vulputate, tristique dolor sit amet, tempus sem. Vivamus euismod, ipsum vitae fermentum sodales, risus diam dignissim ipsum, a hendrerit nisl lacus nec lacus. Vestibulum a turpis iaculis, pharetra tortor ac, eleifend magna. Vivamus cursus massa libero, et lacinia quam fermentum a. Fusce molestie lorem eu placerat hendrerit. Morbi mauris massa, laoreet sed neque at, tempor dignissim dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse nibh felis, hendrerit at libero et, ultrices pharetra ipsum. Etiam condimentum velit ullamcorper vehicula tincidunt. 
              </p>
            </div>
        </div>
    </div>
</div>

