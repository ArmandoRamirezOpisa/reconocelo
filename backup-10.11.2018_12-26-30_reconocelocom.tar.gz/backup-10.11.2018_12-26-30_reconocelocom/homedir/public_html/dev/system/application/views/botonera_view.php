    <div id="botonera">
        <div class="btn_m btn1">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Clipboard.png"></span>
            <a href="javascript:void(0)" onclick="loadSection('reglas_controller','dvSecc')"><h3 class="btnTit">Reglas</h3></a>
        </div>
        <div class="btn_m btn2">
            <div class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Compas.png"></div>
            <a href="javascript:void(0)" onclick="loadSection('producto_controller','dvSecc')"><h3 class="btnTit">Productos</h3></a>
        </div>
        <div class="btn_m btn3">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Gift-Box.png"></span>
            <a href="javascript:void(0)" onclick="loadSection('cart_controller/getCategory','dvSecc')"><h3 class="btnTit">Premios</h3></a>
        </div>
        <div class="btn_m btn4">
            <span class="imgBtn"><img class="imgInBtna" src="assets/images/icons/Pocket.png"></span>
            <a href="javascript:void(0)" onclick="loadSection('canje_controller/getCanjes','dvSecc')"><h3 class="btnTit">Mis Canjes</h3></a>
        </div>
    </div>